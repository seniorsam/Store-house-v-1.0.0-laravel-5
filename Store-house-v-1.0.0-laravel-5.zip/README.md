# Store-house-v-1.0.0-laravel-5

## What is the idea?

Imagine that you have a store house, and you want you manage it and allow other people who are work in the store to sign up their accounts and allow them to post their discussions in order to discuss it. also you want to manage items, application users in the store such as insert items or update user accounts etcetera.

## what features you have done so far in version 1.0.0 ?

### Users section

* Authentication.
* user profiles which contain user data and their posted discussions in the application also the ability to update some of their information.
* user rules which differentiate the privileges for each user such as user admin and regular user.

### Items section.

* search function that allow user to search for a specific items in the database.
* page for display the available items in the database.

### Discussion section.

* the ability to add a discussion to be accessable by any authenticated user to give their opinion about it.
* also you can post you comment on the discussion.

### Application dashboard

* Display authenticated users and inserted items.
* update or delete users information.
* insert or Update or delete items information.

### used technologies.

* PHP Framework Laravel 5 to communicate with the database and processing the data.
* Bootstrap for the application interface.
* gravatar for users profile pictures.


  #### Thank you 
