<?php namespace storeHouse\Events;

abstract class Event {

	//

}
