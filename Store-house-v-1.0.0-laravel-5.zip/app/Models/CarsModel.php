<?php namespace storeHouse\Models;

use Illuminate\Database\Eloquent\Model;

class CarsModel extends Model {

	protected $table = 'sthcars_models';

	protected $fillable = [
		'name',
		'sthcars_manufactures_id',
		'active'
	];

	public function carsmanufactures(){
		return $this->belongsTo('storeHouse\Models\Manufacture', 'sthcars_manufactures_id');
	}

}
