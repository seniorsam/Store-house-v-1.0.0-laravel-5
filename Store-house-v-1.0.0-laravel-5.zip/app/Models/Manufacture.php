<?php namespace storeHouse\Models;

use Illuminate\Database\Eloquent\Model;

class Manufacture extends Model {

	protected $table = 'sthcars_manufactures';

	protected $fillable = [
		'name',
		'active'
	];

	public function carsmodels(){
		return $this->hasMany('storeHouse\Models\CarsModel', 'sthcars_manufactures_id');
	}

}
