<?php namespace storeHouse\Models;

use Illuminate\Database\Eloquent\Model;

class Car extends Model {

	protected $table = 'sthcars';

	protected $fillable = [
	 'sthcars_manufactures_id', 
	 'sthcars_models_id', 
	 'car_released', 
	 'car_showcase', 
	 'car_color',
	 'car_description',
	 'active'
	];

	public function users(){
		return $this->belongsTo('storeHouse\Models\User', 'sthusers_id');
	}

	public function manufactures(){
		return $this->belongsTo('storeHouse\Models\Manufacture', 'sthcars_manufactures_id');
	}

	public function models(){
		return $this->belongsTo('storeHouse\Models\CarsModel', 'sthcars_models_id');
	}

}
