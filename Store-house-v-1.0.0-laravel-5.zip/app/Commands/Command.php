<?php namespace storeHouse\Commands;

abstract class Command {

	//

}
