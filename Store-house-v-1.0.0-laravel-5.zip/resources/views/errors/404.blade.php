<style>
	.text-center {
		text-align: center;
	}
	a {
		text-decoration: none;
		text-align: center;
		display: block;
	}
</style>
<h1 class="text-center">404 . Page not found</h1>
<a href="{{route('home')}}">Return back to home page</a>