@extends('templates.default')
@section('content')
	<h2>Add Manufacture:</h2>
	<hr>
	<form method="post" action="{{route('dashboard.carmanufacture.insert')}}">

	<div class="form-group {{$errors->first('name') ? ' has-error' : ''}}">
		<label for="item_name">Name</label>
		<input type="text" class="form-control" id="name" name="name" placeholder="Name">
		@if($errors->first('name'))
			<span class="label label-danger">
				{{$errors->first('name')}}
			</span>
		@endif
	</div>

	<div class="checkbox">
		<label>
			<input type="checkbox" name="active"> Publish this manufacture
		</label>
	</div>
 
	<button type="submit" class="btn btn-primary">Submit</button>
	<input type="hidden" name="_token" value="{{Session::token()}}">
	</form>

	<h2>Available manufactures:</h2>
	<hr>
	@if( $manufactures->count() == 0)
		<div class="alert alert-info alert-dismissible fade in" role="alert"> 
			There is no available items
		</div>
	@else
	<div class="table-responsive">
		<table class="table table-bordered">
			<thead> 
				<tr> 
					<th>#</th>
					<th>Name</th> 
					<th>State</th>  
					<th class="text-info">Actions</th>  
					<th class="text-danger">Delete</th> 
				</tr> 
			</thead>
			<tbody>	
				@foreach($manufactures as $manufacture)
					<tr> 
						<th scope="row">{{$manufacture->id}}</th>  
						<td>{{$manufacture->name}}</td> 
						<td class="text-success">
							<strong>
								{{ $manufacture->active ? 'Published' : 'Not published' }}
							</strong>
						</td> 
						<td>...</td>
						<td><a class="deleteUserFromDashboard text-danger" href="..." title="delete this item"><span class="glyphicon glyphicon-remove" aria-hidden="true"></span></a></td> 
					</tr>
				@endforeach
			</tbody>
		</table>
	</div>	
	@endif
@stop