@extends('templates.default')
@section('content')
	<h2>Cars:</h2>
	<hr>
	@if($cars->count() == 0)
		<div class="alert alert-info alert-dismissible fade in" role="alert"> 
			There is no available items
		</div>
	@endif
	<div class="table-responsive">
		<table class="table table-bordered">
			<thead> 
				<tr> 
					<th>#</th>
					<th>Manufacture</th> 
					<th>Model</th> 
					<th>Year</th> 
					<th>picture</th> 
					<th>color</th> 
					<th>Description</th>  
					<th>State</th>  
					<th>Insertd by</th>  
					<th class="text-info">Actions</th>  
					<th class="text-danger">Delete</th> 
				</tr> 
			</thead>
			<tbody>	
				@foreach($cars as $car)
					<tr> 
						<th scope="row">{{$car->id}}</th> 
						<td>{{$car->manufactures->name}}</th> 
						<td>{{$car->models->name}}</td> 
						<td>{{$car->car_released}}</td> 
						<td>
							<img width="100px" height="auto" src="/images/carPictures/{{$car->car_showcase ? $car->car_showcase : 'thumb.jpg'}}" alt="{{$car->car_showcase}}">
						</td> 
						<td>{{$car->car_color}}</td> 
						<td>{{$car->car_description}}</td> 
						<td class="text-success"><strong>{{$car->active ? 'Published' : 'Not published'}}</strong></td> 
						<td>{{$car->users->username}}</td> 
						<td>...</td>
						<td><a class="deleteUserFromDashboard text-danger" href="..." title="delete this item"><span class="glyphicon glyphicon-remove" aria-hidden="true"></span></a></td> 
					</tr>
				@endforeach
			</tbody>
		</table>
	</div>	
	
@stop