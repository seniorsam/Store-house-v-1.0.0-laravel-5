@extends('templates.default')
@section('content')
	<h2>Add Model:</h2>
	<hr>
	<form method="post" action="{{route('dashboard.carmodel.insert')}}">

	<div class="form-group {{$errors->first('name') ? ' has-error' : ''}}">
		<label for="item_name">Name</label>
		<input type="text" class="form-control" id="name" name="name" placeholder="Name">
		@if($errors->first('name'))
			<span class="label label-danger">
				{{$errors->first('name')}}
			</span>
		@endif
	</div>

	<div class="form-group {{$errors->first('name') ? ' has-error' : ''}}">
		<select name="manufacture" class="form-control">
			<option value="">Choose manufacture</option>
			@foreach($manufactures as $manufacture)
			<option value="{{$manufacture->id}}">{{$manufacture->name}}</option>
			@endforeach
		</select>
		@if($errors->first('manufacture'))
			<span class="label label-danger">
				{{$errors->first('name')}}
			</span>
		@endif
	</div>

	<div class="checkbox">
		<label>
			<input type="checkbox" name="active"> Publish this model
		</label>
	</div>
 
	<button type="submit" class="btn btn-primary">Submit</button>
	<input type="hidden" name="_token" value="{{Session::token()}}">
	</form>

	<h2>Available models:</h2>
	<hr>
	@if( $models->count() == 0)
		<div class="alert alert-info alert-dismissible fade in" role="alert"> 
			There is no available models
		</div>
	@else
	<div class="table-responsive">
		<table class="table table-bordered">
			<thead> 
				<tr> 
					<th>#</th>
					<th>Name</th> 
					<th>Manufacture</th>  
					<th>State</th>  
					<th class="text-info">Actions</th>  
					<th class="text-danger">Delete</th> 
				</tr>
			</thead>
			<tbody>	
				@foreach($models as $model)
					<tr> 
						<th scope="row">{{$model->id}}</th>  
						<td>{{$model->name}}</td> 
						<td>{{$model->carsmanufactures->name}}</td> 
						<td class="text-success">
							<strong>
								{{ $model->active ? 'Published' : 'Not published' }}
							</strong>
						</td> 
						<td>...</td>
						<td><a class="deleteUserFromDashboard text-danger" href="..." title="delete this item"><span class="glyphicon glyphicon-remove" aria-hidden="true"></span></a></td> 
					</tr>
				@endforeach
			</tbody>
		</table>
	</div>
	@endif
@stop