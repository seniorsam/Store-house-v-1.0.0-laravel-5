@extends('templates.default')
@section('content')
	<h2>Add car:</h2>
	<hr>
	<form method="post" action="{{route('dashboard.car.insert')}}" enctype="multipart/form-data">

	<div class="form-group {{$errors->first('manufacture') ? ' has-error' : ''}}">	
		<select name="manufacture" class="form-control">
			<option value="">Choose manufacture</option>
			@foreach($manufactures as $manufacture)
				<option value="{{$manufacture->id}}">{{$manufacture->name}}</option>
			@endforeach
		</select>
		@if($errors->first('manufacture'))
			<span class="label label-danger">
				{{$errors->first('manufacture')}}
			</span>
		@endif
	</div>

	<div class="form-group {{$errors->first('sthcars_models_id') ? ' has-error' : ''}}">
		<select name="sthcars_models_id" class="form-control">
			<option value="">Choose model</option>
			@foreach($models as $model)
				<option value="{{$model->id}}">{{$model->name}}</option>
			@endforeach
		</select>
		@if($errors->first('sthcars_models_id'))
			<span class="label label-danger">
				{{$errors->first('sthcars_models_id')}}
			</span>
		@endif
	</div>

	<div class="form-group">
		<label for="car_showcase">Upload picture</label>
		<input type="file" name="car_showcase" class="form-control">
		@if($errors->first('car_showcase'))
			<span class="label label-danger">
				{{$errors->first('car_showcase')}}
			</span>
		@endif
	</div>

	<div class="form-group {{$errors->first('car_release_date') ? ' has-error' : ''}}">
		<label for="car_release_date">Car release date</label>
		<input type="date" class="form-control" name="car_release_date" value="{{Request::old('car_release_date') ? Request::old('car_release_date') : ''}}">
		@if($errors->first('car_release_date'))
			<span class="label label-danger">
				{{$errors->first('car_release_date')}}
			</span>
		@endif
	</div>

	<div class="form-group {{$errors->first('car_color') ? ' has-error' : ''}}">
		<label for="car_color">Car color</label>
		<input type="text" class="form-control" name="car_color" placeholder="Color" value="{{Request::old('car_color') ? Request::old('car_color') : ''}}">
		@if($errors->first('car_color'))
			<span class="label label-danger">
				{{$errors->first('car_color')}}
			</span>
		@endif
	</div>

	<div class="form-group {{$errors->first('car_description') ? ' has-error' : ''}}">
		<label for="car_description">Car description</label>
		<textarea class="form-control" name="car_description" cols="30" rows="10">{{Request::old('car_description') ? Request::old('car_description') : ''}}</textarea>
			@if($errors->first('car_description'))
			<span class="label label-danger">
				{{$errors->first('car_description')}}
			</span>
			@endif
	</div>

	<div class="checkbox">
		<label>
			<input type="checkbox" name="active"> Publish this manufacture
		</label>
	</div>
 
	<button type="submit" class="btn btn-primary">Submit</button>
	<input type="hidden" name="_token" value="{{Session::token()}}">
	</form>
@stop