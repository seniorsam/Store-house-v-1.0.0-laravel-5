@extends('templates.default')
@section('content')
	<h2>Dashboard:</h2>
	<hr><br>
	<h4>Statistics</h4>
	<hr>
	<div class="row">

		<div class="col-md-2">
			<div class="mylabel label-primary">
				<h3>Users <br> 55</h3>
			</div>
		</div>		

		<div class="col-md-2">
			<div class="mylabel label-danger">
				<h3>Items <br> 55</h3>	
			</div>
		</div>

		<div class="col-md-2">
			<div class="mylabel label-info">
				<h3>Discussions <br> 55</h3>	
			</div>
		</div>

		<div class="col-md-2">
			<div class="mylabel label-success">
				<h3>Comments <br> 55</h3>	
			</div>
		</div>

		<div class="col-md-2">
			<div class="mylabel label-default">
				<h3>Items <br> 55</h3>	
			</div>
		</div>

		<div class="col-md-2">
			<div class="mylabel label-primary">
				<h3>Items <br> 55</h3>	
			</div>
		</div>

	</div><br><br>
	<h4>Options</h4>
	<hr>

	<div class="btn-group" role="group" aria-label="...">

		<!--<button type="button" class="btn btn-primary">
	  	 	<span class="glyphicon glyphicon-cog" aria-hidden="true"></span>
	  	 	Cpanel
	  	 </button>  -->

		<a href="{{route('dashboard.users')}}" type="button" class="btn btn-default">
			<span class="glyphicon glyphicon-user" aria-hidden="true"></span> 
			Manage users
		</a>

		<a href="{{route('dashboard.discussions')}}" type="button" class="btn btn-success">
			<span class="glyphicon glyphicon-sunglasses" aria-hidden="true"></span> 
			Manage discussions
		</a>

		<div class="btn-group"> 
			<button type="button" class="btn btn-primary">
				<span class="glyphicon glyphicon-th" aria-hidden="true"></span>
				Items
			</button> 
			<button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
			 <span class="caret"></span> 
			 <span class="sr-only">
			 	Toggle Dropdown
			 </span> 
			</button> 

			 <ul class="dropdown-menu"> 

			 	<li>
			 		<a href="{{route('dashboard.item.add')}}">
			 			<span class="glyphicon glyphicon-plus" aria-hidden="true"></span> 
			 			Add new item
			 		</a>
			 	</li>  

			 	<li>
			 		<a href="{{route('dashboard.items')}}">
			 			<span class="glyphicon glyphicon-cog" aria-hidden="true"></span> 
			 			Manage items
			 		</a>
			 	</li> 

			 </ul> 

		</div>		

		<div class="btn-group"> 
			<button type="button" class="btn btn-primary">
				<span class="glyphicon glyphicon-th" aria-hidden="true"></span>
				Cars
			</button> 
			<button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
			 <span class="caret"></span> 
			 <span class="sr-only">
			 	Toggle Dropdown
			 </span> 
			</button> 

			 <ul class="dropdown-menu"> 


			 	<li>
			 		<a href="{{route('dashboard.carmanufacture.insert')}}">
			 			<span class="glyphicon glyphicon-plus" aria-hidden="true"></span> 
			 			Add new manfacture company
			 		</a>
			 	</li> 			 	

			 	<li>
			 		<a href="{{route('dashboard.carmodel.insert')}}">
			 			<span class="glyphicon glyphicon-plus" aria-hidden="true"></span> 
			 			Add cars models
			 		</a>
			 	</li> 

			 	<li>
			 		<a href="{{route('dashboard.car.insert')}}">
			 			<span class="glyphicon glyphicon-plus" aria-hidden="true"></span> 
			 			Add new car
			 		</a>
			 	</li> 			 	

			 	<li>
			 		<a href="{{route('dashboard.cars')}}">
			 			<span class="glyphicon glyphicon-cog" aria-hidden="true"></span> 
			 			Manage cars
			 		</a>
			 	</li>

			 </ul> 

		</div>
		
	</div>

	<br><br>
@stop